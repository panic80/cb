import React from 'react';

    function Hero() {
      return (
        <div className="hero pt-20">
          <h1 className="">Welcome to Our Chatbot</h1>
          <p>Get instant answers to your questions</p>
        </div>
      );
    }

    export default Hero;
